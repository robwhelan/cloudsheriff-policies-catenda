#config file containing credentials for RDS MySQL instance
db_username = "cloudjanitorz"
db_password = "cloudjanitorz"
db_name = "cloudjanitorz"
rds_instance_endpoint = 'cloudjanitorz.c3cnrieiquqk.us-east-1.rds.amazonaws.com'
